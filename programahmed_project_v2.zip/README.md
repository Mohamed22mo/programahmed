# Expenses management - Android WebView app
Opens http://programahmed.ifree.page/index.php inside an Android app.
Target/compile SDK 36, AGP 8.11.1, Gradle 8.14.3, JDK 17.
Signed release builds read KEYSTORE_PATH, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD from the environment.
